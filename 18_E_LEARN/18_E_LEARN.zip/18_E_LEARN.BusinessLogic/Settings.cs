﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _18_E_LEARN.BusinessLogic
{
    public static class Settings
    {
        public static string ImagePath = @"\images\courses\";
        public static string DefaultCurseImage = "https://www.freeiconspng.com/thumbs/no-image-icon/no-image-icon-6.png";
    }
}
